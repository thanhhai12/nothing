package com.example.githubtest;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.githubtest.api.GitHubService;
import com.example.githubtest.models.FileUploadRequest;
import com.example.githubtest.models.FileUpdateResponse;
import com.example.githubtest.models.Repo;
import com.example.githubtest.viewmodel.RepoViewModel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.util.Base64;
import android.database.Cursor;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class ReposFragment extends Fragment implements RepoAdapter.OnPushClickListener {

    private static final int PICK_FILE_REQUEST_CODE = 1;
    private OnRepoSelectedListener callback;
    private RecyclerView recyclerView;
    private RepoAdapter adapter;
    private RepoViewModel repoViewModel;
    private String selectedRepoOwner;
    private String selectedRepoName;

    public interface OnRepoSelectedListener {
        void onRepoSelected(String owner, String repoName);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnRepoSelectedListener) {
            callback = (OnRepoSelectedListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement OnRepoSelectedListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_repos, container, false);

        recyclerView = view.findViewById(R.id.recycler_view_repos);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new RepoAdapter(new RepoAdapter.OnRepoClickListener() {
            @Override
            public void onRepoClick(Repo repo) {
                onRepositoryClicked(repo);
            }
        }, this); // Set the push click listener to this fragment
        recyclerView.setAdapter(adapter);

        repoViewModel = new ViewModelProvider(this).get(RepoViewModel.class);
        repoViewModel.getRepos().observe(getViewLifecycleOwner(), new Observer<List<Repo>>() {
            @Override
            public void onChanged(List<Repo> repos) {
                adapter.setRepos(repos);
            }
        });

        return view;
    }

    private void onRepositoryClicked(Repo repo) {
        if (callback != null) {
            callback.onRepoSelected(repo.getOwner().getLogin(), repo.getName());
        }
    }

    @Override
    public void onPushClick(Repo repo) {
        // Store the selected repo details
        selectedRepoOwner = repo.getOwner().getLogin();
        selectedRepoName = repo.getName();

        // Launch file picker
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*"); // Set to specific MIME type if needed, e.g., "text/plain" for text files
        startActivityForResult(intent, PICK_FILE_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_FILE_REQUEST_CODE && resultCode == Activity.RESULT_OK && data != null) {
            Uri fileUri = data.getData();
            if (fileUri != null) {
                try {
                    String fileName = getFileName(fileUri);
                    String fileContent = readFileContent(fileUri);

                    // Upload the selected file
                    String commitMessage = "Add " + fileName;
                    uploadFileToRepo(selectedRepoOwner, selectedRepoName, fileName, fileContent, commitMessage);

                } catch (IOException e) {
                    Toast.makeText(getContext(), "Failed to read file content", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }
    }

    // Read file content and encode in Base64
    private String readFileContent(Uri uri) throws IOException {
        InputStream inputStream = getContext().getContentResolver().openInputStream(uri);
        byte[] fileBytes = new byte[inputStream.available()];
        inputStream.read(fileBytes);
        inputStream.close();
        return Base64.encodeToString(fileBytes, Base64.NO_WRAP);
    }

    // Retrieve file name from Uri
    private String getFileName(Uri uri) {
        String fileName = "unknown";
        Cursor cursor = getContext().getContentResolver().query(uri, null, null, null, null);
        if (cursor != null) {
            int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            if (nameIndex >= 0 && cursor.moveToFirst()) {
                fileName = cursor.getString(nameIndex);
            }
            cursor.close();
        }
        return fileName;
    }

    private void uploadFileToRepo(String owner, String repo, String path, String content, String commitMessage) {
        GitHubService service = ApiClient.getGitHubService();
        FileUploadRequest request = new FileUploadRequest(commitMessage, content);

        service.uploadFile(owner, repo, path, request).enqueue(new Callback<FileUpdateResponse>() {
            @Override
            public void onResponse(Call<FileUpdateResponse> call, Response<FileUpdateResponse> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(getContext(), "File pushed successfully to " + repo, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "Failed to push file: " + response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<FileUpdateResponse> call, Throwable t) {
                Toast.makeText(getContext(), "Push failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDetach() {
        super.onDetach();
        callback = null;
    }
}
