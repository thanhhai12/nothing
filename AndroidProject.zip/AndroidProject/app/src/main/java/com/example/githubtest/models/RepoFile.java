package com.example.githubtest.models;

import com.google.gson.annotations.SerializedName;

public class RepoFile {

    @SerializedName("name")
    private String name;

    @SerializedName("path")
    private String path;

    @SerializedName("type")
    private String type;

    @SerializedName("download_url")
    private String downloadUrl;

    public RepoFile(String name, String path, String type, String downloadUrl) {
        this.name = name;
        this.path = path;
        this.type = type;
        this.downloadUrl = downloadUrl;
    }

    public String getName() {
        return name;
    }

    public String getPath() {
        return path;
    }

    public String getType() {
        return type;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public boolean isFile() {
        return "file".equals(type);
    }

    public boolean isDirectory() {
        return "dir".equals(type);
    }
}
