package com.example.githubtest;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.githubtest.api.GitHubService;
import com.example.githubtest.models.FileContent;
import com.example.githubtest.models.RepoFile;
import com.example.githubtest.viewmodel.RepositoryDetailViewModel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import java.io.OutputStream;
import java.util.List;

public class RepositoryDetailFragment extends Fragment implements RepoFileAdapter.OnDownloadClickListener {

    private static final String ARG_REPO_NAME = "repo_name";
    private static final String ARG_OWNER = "owner";
    private static final int PICK_DIRECTORY_REQUEST_CODE = 2;
    private RepositoryDetailViewModel viewModel;
    private RecyclerView recyclerView;
    private RepoFileAdapter adapter;
    private String selectedFileName;
    private String selectedFileContent;

    public static RepositoryDetailFragment newInstance(String owner, String repoName) {
        RepositoryDetailFragment fragment = new RepositoryDetailFragment();
        Bundle args = new Bundle();
        args.putString(ARG_REPO_NAME, repoName);
        args.putString(ARG_OWNER, owner);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_repository_detail, container, false);
        recyclerView = view.findViewById(R.id.recycler_view_repo_files);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize adapter with OnDownloadClickListener
        adapter = new RepoFileAdapter(new RepoFileAdapter.OnFileClickListener() {
            @Override
            public void onFileClick(String filePath) {
                onFileClicked(filePath);
            }
        }, this); // Set the download listener to this fragment
        recyclerView.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(RepositoryDetailViewModel.class);

        if (getArguments() != null) {
            String owner = getArguments().getString(ARG_OWNER);
            String repoName = getArguments().getString(ARG_REPO_NAME);
            viewModel.loadRepoFiles(owner, repoName);
        }

        viewModel.getRepoFiles().observe(getViewLifecycleOwner(), new Observer<List<RepoFile>>() {
            @Override
            public void onChanged(List<RepoFile> files) {
                adapter.setRepoFiles(files);
            }
        });
        return view;
    }

    @Override
    public void onDownloadClick(RepoFile repoFile) {
        String owner = getArguments().getString(ARG_OWNER);
        String repoName = getArguments().getString(ARG_REPO_NAME);

        // Fetch file content from GitHub
        downloadFileContent(owner, repoName, repoFile.getPath(), repoFile.getName());
    }

    private void downloadFileContent(String owner, String repo, String path, String fileName) {
        GitHubService service = ApiClient.getGitHubService();
        service.getFileContent(owner, repo, path).enqueue(new Callback<FileContent>() {
            @Override
            public void onResponse(Call<FileContent> call, Response<FileContent> response) {
                if (response.isSuccessful() && response.body() != null) {
                    selectedFileName = fileName;
                    selectedFileContent = response.body().getContent();
                    openDirectoryPicker(); // Open directory picker after getting content
                } else {
                    Toast.makeText(getContext(), "Failed to download file", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<FileContent> call, Throwable t) {
                Toast.makeText(getContext(), "Download failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Launch the directory picker to choose the download location
    private void openDirectoryPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        startActivityForResult(intent, PICK_DIRECTORY_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_DIRECTORY_REQUEST_CODE && resultCode == Activity.RESULT_OK && data != null) {
            Uri directoryUri = data.getData();
            if (directoryUri != null) {
                saveFileToDirectory(directoryUri);
            }
        }
    }

    // Save the file to the selected directory
    private void saveFileToDirectory(Uri directoryUri) {
        try {
            // Decode content from Base64
            byte[] decodedBytes = Base64.decode(selectedFileContent, Base64.DEFAULT);

            // Create a new file in the selected directory
            DocumentFile pickedDir = DocumentFile.fromTreeUri(requireContext(), directoryUri);
            DocumentFile newFile = pickedDir.createFile("application/octet-stream", selectedFileName);

            // Write the decoded content to the file
            try (OutputStream outputStream = requireContext().getContentResolver().openOutputStream(newFile.getUri())) {
                if (outputStream != null) {
                    outputStream.write(decodedBytes);
                    Toast.makeText(getContext(), "File downloaded to " + pickedDir.getUri().getPath(), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            Toast.makeText(getContext(), "Failed to save file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void onFileClicked(String filePath) {
        String owner = getArguments().getString(ARG_OWNER);
        String repoName = getArguments().getString(ARG_REPO_NAME);

        // Navigate to FileContentFragment
        FileContentFragment fragment = FileContentFragment.newInstance(owner, repoName, filePath);
        getParentFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }
}
