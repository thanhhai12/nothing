package com.example.githubtest;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.githubtest.models.RepoFile;
import com.example.githubtest.viewmodel.RepositoryDetailViewModel;
import java.util.List;

public class RepositoryDetailFragment extends Fragment {

    private static final String ARG_REPO_NAME = "repo_name";
    private static final String ARG_OWNER = "owner";
    private RepositoryDetailViewModel viewModel;
    private RecyclerView recyclerView;
    private RepoFileAdapter adapter;

    public static RepositoryDetailFragment newInstance(String owner, String repoName) {
        RepositoryDetailFragment fragment = new RepositoryDetailFragment();
        Bundle args = new Bundle();
        args.putString(ARG_REPO_NAME, repoName);
        args.putString(ARG_OWNER, owner);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_repository_detail, container, false);
        recyclerView = view.findViewById(R.id.recycler_view_repo_files);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize adapter with OnFileClickListener
        adapter = new RepoFileAdapter(new RepoFileAdapter.OnFileClickListener() {
            @Override
            public void onFileClick(String filePath) {
                onFileClicked(filePath);
            }
        });
        recyclerView.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(RepositoryDetailViewModel.class);

        if (getArguments() != null) {
            String owner = getArguments().getString(ARG_OWNER);
            String repoName = getArguments().getString(ARG_REPO_NAME);
            viewModel.loadRepoFiles(owner, repoName);
        }

        viewModel.getRepoFiles().observe(getViewLifecycleOwner(), new Observer<List<RepoFile>>() {
            @Override
            public void onChanged(List<RepoFile> files) {
                adapter.setRepoFiles(files);
            }
        });
        return view;
    }

    private void onFileClicked(String filePath) {
        String owner = getArguments().getString(ARG_OWNER);
        String repoName = getArguments().getString(ARG_REPO_NAME);

        // Navigate to FileContentFragment
        FileContentFragment fragment = FileContentFragment.newInstance(owner, repoName, filePath);
        getParentFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }
}
