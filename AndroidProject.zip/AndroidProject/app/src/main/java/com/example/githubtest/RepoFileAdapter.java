package com.example.githubtest;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.githubtest.models.RepoFile;
import java.util.ArrayList;
import java.util.List;

public class RepoFileAdapter extends RecyclerView.Adapter<RepoFileAdapter.RepoFileViewHolder> {

    private List<RepoFile> repoFiles = new ArrayList<>();
    private OnFileClickListener onFileClickListener;

    public interface OnFileClickListener {
        void onFileClick(String filePath);
    }

    public RepoFileAdapter(OnFileClickListener listener) {
        this.onFileClickListener = listener;
    }

    @NonNull
    @Override
    public RepoFileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_repo_file, parent, false);
        return new RepoFileViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RepoFileViewHolder holder, int position) {
        RepoFile repoFile = repoFiles.get(position);
        holder.fileNameTextView.setText(repoFile.getName());

        // Set click listener for each file
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onFileClickListener != null) {
                    onFileClickListener.onFileClick(repoFile.getPath());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return repoFiles.size();
    }

    public void setRepoFiles(List<RepoFile> files) {
        this.repoFiles = files;
        notifyDataSetChanged();
    }

    static class RepoFileViewHolder extends RecyclerView.ViewHolder {
        TextView fileNameTextView;

        RepoFileViewHolder(@NonNull View itemView) {
            super(itemView);
            fileNameTextView = itemView.findViewById(R.id.file_name_text_view);
        }
    }
}
