package com.example.githubtest.models;

import com.google.gson.annotations.SerializedName;

public class FileUpdateResponse {

    @SerializedName("content")
    private RepoFile content;

    @SerializedName("commit")
    private Commit commit;

    public RepoFile getContent() {
        return content;
    }

    public Commit getCommit() {
        return commit;
    }

    public static class Commit {
        @SerializedName("sha")
        private String sha;

        @SerializedName("message")
        private String message;

        public String getSha() {
            return sha;
        }

        public String getMessage() {
            return message;
        }
    }
}
