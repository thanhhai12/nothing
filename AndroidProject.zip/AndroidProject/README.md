

*FIRST THING FIRST*: Vì API_TOKEN thuộc dạng thông tin bảo mật,
theo chính sách của github và google drive, 
hay 1 số dạng lưu trữ và chia sẻ file trực tuyến khác là sẽ không được phép chia sẻ
nên để chia sẻ và sử dụng được ae nén project của mình lại rồi mới push lên github


1. Thiết lập Retrofit để kết nối với GitHub API
trong build.gradle.kts ( module: app) đã thêm: 

implementation 'com.squareup.retrofit2:retrofit:2.9.0'
implementation 'com.squareup.retrofit2:converter-gson:2.9.0'


2. Tạo một interface để định nghĩa các endpoints API ( GitHubService.java)
3. Sử dụng API token để xác thực và kết nối:

Trong gradle.properties tôi đã khai báo

GITHUB_API_TOKEN=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

Sau đó config trong file build.gradle.kts để xác thực kết nối token api đã khai báo:

    defaultConfig {
        applicationId = "com.example.githubtest"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        buildConfigField("String", "GITHUB_API_TOKEN", "\"${project.findProperty("GITHUB_API_TOKEN") ?: ""}\"")

    }

// Phần này để bật tính năng buildConfig

    buildFeatures {
        buildConfig = true  
    }

4. Cho phép kết nối INTERNET để truy cập website github, lấy thông tin từ api đã xác thực (thực hiện trong AndroidManifest.xml)

    <uses-permission android:name="android.permission.INTERNET"/>

5. Tạo giao diện bằng file mainactivity.xml cũng như các file fragment( cụ thể là file fragment_repos.xml và fragment_workflows.xml)
Bên cạnh đó dùng navigation_drawer để tạo mục để navigate giữa các fragment.
ngoài ra, còn có một số thiết kế lặt vặt ở trong:
-res/menu để cấu hình design của navigation navigation_drawer
- các item_repo.xml, item_workflow.xml để generate các repo và workflow sau khi fetch api
- string.xml để hiển thị tên app, tên ảnh avatar và tính năng bật tắt navigation
- fragment setting.xml chưa có gì cả, để mặc định,  cho vào cho có


6. Sử dụng các model( Repo và WorkFlowRun) để khái quát bố cục của dữ liệu hiển thị sau khi fetch api
7. Sử dụng method ViewModel để hiển thị các dữ liệu đó trên các fragment, bằng cách kết nối chúng với nhau bằng Adapter
8. Tạo file APIClient.java là một lớp để quản lý việc cấu hình và khởi tạo Retrofit – một HTTP client giúp kết nối đến API


Cập nhật ngày 5/11/2024:

10. - Trong thư mục model, RepoFile dùng để tạo form cho các file có trong repositories
    - Trong thư mục viewmodel, RepositoriyViewModel giúp nhận form, kết nối với ReposFragment và hiển thị các file trong repositories theo đúng form
    - RepoFileAdapter.java giúp thực hiện các thao tác như bấm vào file hiển thị nội dung file, bấm vào Thư mục repo, hiển thị các file trong repositories
    - một số file xml mới như: fragment_repository_detail.xml, fragment_file_content.xml để hiển thị layout của các file trong repo và nội dung của các file đó lên front-end.



Một số lưu ý: 
- Sử dụng Java, không dùng Klotin
- Muốn thêm dependencies gì thì Chỉ sử dụng buil.gradle.kts(Module: app)
- Sửa cái gì trong file build.gradle.kts và gradle.properties xong thì phải Sync Now
- Nếu chạy mà không thấy hiện gì trong repositories thì nghĩa là token đã hết hạn hoặc bị hỏng, hãy tự generate 1 token mới rồi thêm vào như ở mục 3. 

cách lấy API_TOKEN của github:

Bước 1: Đăng nhập vào github
Bước 2: Bấm vào Profile Avater chọn setting
Bước 3: Ở menu bên trái, kéo xuống cuối cùng, chọn mục Developer Settings
Bước 4: Click vào Personal Access Token chọn Tokens (classic)
Bước 5: Ở phần Generate new token chọn classic
Bước 6: Tick các mục về repositories, workflow và user và chọn generate
Bước 7: Copy token và lưu trữ ở đâu đó ( vì nó chỉ hiển thị 1 lần duy nhất, sau đó thực hiện như ở bước 3. để chạy project với token)
